//this function prevents the data being sent to the database before it has been validated

/*on button click gets all values from input fields, calls a function to check if required fields are blank
if they are an alert displays, checks if the email entered is a valid email adress*/
$(".error").hide();

$("#Form-btn").on("click",function(e){
    let requiredfields = [
        {selector: $("#Fname"), empty: true, error: $("#FNameError")},
        {selector: $("#Lname"), empty: true, error: $("#LNameError")},
        {selector: $("#Email"), empty: true, error: $("#EmailError")}
    ]
    let optionalfields = [
        {selector: $("#Subject"), empty: false},
        {selector: $("#Message"), empty: false}
    ]
    let emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    if(required(requiredfields)){
        if(!emailReg.test(requiredfields[2].selector.val())){
            requiredfields[2].selector.addClass("form-error");
            requiredfields[2].error.html("<p>Please enter a valid email address</p>");
            requiredfields[2].error.show().slideUp().slideDown();
            $ ("#contactform").submit( function() {
                return false;
            });
        } else {
            requiredfields[2].error.slideUp();
            requiredfields[2].selector.removeClass("form-error");
            if(optionalfields[0].selector.val()===""){
                optionalfields[0].selector = prompt("Please enter a Subject or a predetermined one will be applied");
            }
            if(optionalfields[1].selector.val()===""){
                optionalfields[1].selector = prompt("Please enter a message or a predetermined one will be applied");
            }
            
        }
    } else {
        
    }
});
/*this function gets required fields array passed into it then checks if any fields
    are empty if they are then the fields background color changes to red*/
function required(arr){
    let isempty = false;
    for (let i = 0; i < arr.length;i++){
        if(arr[i].selector.val().trim() === ""){
            arr[i].empty = true;
            arr[i].error.show().slideUp().slideDown();
            arr[i].error.html("<p>Required field is empty</p>");
            arr[i].selector.addClass("form-error");
            $ ("#contactform").submit( function() {
                return false;
            });
        } else {
            arr[i].empty = false;
            arr[i].error.slideUp();
            arr[i].selector.removeClass("form-error");
        }
    }
    for(let i = 0; i < arr.length;i++){
        if(arr[i].empty){
            isempty = true;
        }
    }
    if(isempty){
        return false;
    } else {
        return true;
    }
}