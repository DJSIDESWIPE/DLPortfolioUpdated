let $sidebar = $(".sidebar");

$("#sidebar-btn").on("click", function(){
    
    if ($sidebar.css("display") === "none"){
        $sidebar.attr("id","show-sidebar");
        $(this).css("left","200px");
    } else {
        $sidebar.removeAttr("id");
        $(this).css("left", "50px")
    }
});
