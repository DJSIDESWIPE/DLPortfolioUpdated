/*types out each letter of the text entered into the function
to the element referenced
*/
async function typeWriter(sentence, eleRef, delay = 100) {
    $(eleRef).html("");
    const letters = sentence.split("");
    let i = 0;
    while(i < letters.length) {
      await waitForMs(delay);
      $(eleRef).append(letters[i]);
      i++
    }
    return;
  }
  
  //delays the amount of miliseconds entered into the function 
  function waitForMs(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  typeWriter("My name is David Leverton", "#Banner-Header", 50);
  typeWriter("I am a Junior web developer", "#Banner-Text", 75);