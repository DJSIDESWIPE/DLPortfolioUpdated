<!DOCTYPE html>
<html>
    <head>
        <title>DL Portfolio</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="StyleSheet" href="./css/Portfolio.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <?php
                include "./php/contact-form.php";
            ?>
    </head>
    <body>
        <div class="sidebar-container">
            <button id="sidebar-btn" class="hamburger-menu"><i class="fa fa-bars" aria-hidden="true"></i></button>
            <div class="sidebar">
                <div class="sidebar-header">
                    <a class="initials-link" href="index.html">
                        <h2 class="initials">DL</h2>
                    </a>
                </div>
                <ul>
                    <a href="AboutMe.html"><li>About Me</li></a> 
                    <a href="#Portfolio" class="active"><li>My Portfolio</li></a>
                    <a href="CodingExamples.html"><li>Coding Examples</li></a>
                    <a href="SCSScheme.html"><li>SCS Scheme</li></a>
                </ul>
                <div class="Contact-Me">
                    <a href="#Contact"><b><p>Contact Me</p></b></a>
                </div>
                <div>
                    <a href="https://github.com/DJSIDESWIPE"><img class="github-logo" src="./img/github-mark.png" alt="github logo"></a>
                </div>
            </div>
        </div>
        <div class="banner-container" id="Banner">
            <h1 id="Banner-Header">My name is David Leverton</h1>
            <p id="Banner-Text">I'm a Web Developer</p>
            <a href="#Portfolio">scroll down <br>
                <i class="fa fa-chevron-down" aria-hidden="true"></i>
            </a>
        </div>
        <div class="portfolio-container" id="Portfolio">
            <h2>Projects</h2>
            <div class="project">
                <div class="image-container">
                    <img class="Project-image" src="./img/JAR-img.PNG"> 
                </div>                 
                <h2>
                    JavaScript Array Reflection
                </h2>
                <p>This task gets a random image and allows the user to store it against an email address</p>
                <a href="https://djsideswipe.github.io/DLJavaScriptArrayReflection/">View Project <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
            </div>  
            <div class="project">
                <div class="image-container">
                    <img class="Project-image" src="./img/netmatterswebsite.PNG">
                </div>
                <h2>
                    Netmatters Website
                </h2>
                <p>
                    This project was to recreate the netmatters home and contact page
                </p>
                <a href="https://netmatters.david-leverton.netmatters-scs.co.uk">View Project <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
            </div>      
        </div>
        <div class="contact-container" id="Contact">
            <div class="contact-content">
            <div class="contact-text">
                <h2>Get In Touch</h2>
                <b>
                    <p class="GIT-Mobile">Mobile: 07923 413887</p>
                    <p class="GIT-Email">Email: djleverton@outlook.com</p>
                </b>
            </div>
            
            <form id="contactform" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST"  class="contact-form">
                <span class="error" id="FNameError"></span>
                <div class="name-fields">
                    <input name="FName" id="Fname" placeholder="First Name*" value="<?php echo $firstname; ?>">
                    <input name="LName" id="Lname" placeholder="LastName*" value="<?php echo $lastname; ?>">
                </div>
                <span class="error" id="LNameError"></span>
                <input name="Email" id="Email" placeholder="Email Address*" value="<?php echo $email; ?>">
                <span class="error" id="EmailError"></span>
                <input name="Subject" id="Subject" placeholder="Subject" value="<?php echo $subject; ?>">
                <span class="error" id="SubjectError"></span>
                <textarea name="Message" id="Message" placeholder="Message" value="<?php echo $message; ?>"></textarea>
                <span class="error" id="MessageError"></span>
                <input id="Form-btn" type="submit">
            </form>
            </div>
        </div>
        <div class="phperrors" style="width:50vw;margin:10px auto; text-align:center;overflow-wrap: break-word;">
            <?php
                echo $errormessage;
            ?>
        </div>
        <div class="back-to-top-container">
            <a href="#Banner"><i class="fa fa-chevron-up" aria-hidden="true"></i><br>
                back to top
            </a>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="./js/Navbar.js"></script>
        <script src="./js/banner-effect.js"></script>
        <script src="./js/Validate.js"></script>
    </body>
</html>