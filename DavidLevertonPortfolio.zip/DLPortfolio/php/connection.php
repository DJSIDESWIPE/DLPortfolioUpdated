<?php
	
	$Servername = "localhost";
	$Username = "davidlev_main-user";
	$Password = "djsideswipe1.";
	$DBname = "davidlev_portfolio";
    // $Servername = "localhost";
	// $Username = "root";
	// $Password = "";
	// $DBname = "davidlev_portfolio";

	try{
        //creates a connection to the database
        $conn = new PDO("mysql:host=$Servername;dbname=$DBname", $Username, $Password);
    } catch (PDOException $e) {
        print "Error!: " . $e->getMessage() . "<br/>";
        die();
    }
    
	//echo "Connected successfully"; 
	
	
?>