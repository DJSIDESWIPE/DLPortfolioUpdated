<?php
    include "./php/connection.php";
    //all variables are assigned here
    $Error = false;
    $errormessage = "";
    $firstname = $lastname = $email = $subject = $message = "";

    // gets all user input by a post method 
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $errormessage = "";
        if (empty($_POST["FName"])) {
			$Error = true;
            $errormessage = $errormessage . "<p class='form-error'>Firstname is required</p>";
		} else {
			$firstname = test_input($_POST["FName"]);
		}

        if (empty($_POST["LName"])) {
			$Error = true;
            $errormessage = $errormessage . "<p class='form-error'>Lastname is required</p>";
		} else {
			$lastname = test_input($_POST["LName"]);
		}

        if (empty($_POST["Email"])) {
			$Error = true;
            $errormessage = $errormessage . "<p class='form-error'>Email is required</p>";
		} else {
			$email = test_input($_POST["Email"]);
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errormessage = $errormessage . "<p class='form-error'>invalid Email</p>";
				$Error = true;
			}
		}

        if (empty($_POST["Subject"])) {
            $subject = "Email About Portfolio";
        } else {
            $subject = test_input($_POST["Subject"]);
            
        }
    
        if (empty($_POST["Message"])) {
            $message = "Default message sent from Portfolio user.";
        } else {
            $message = test_input($_POST["Message"]);
        }
        
    }

    //if any errors are found then it doesn't send to the database
    if(!$Error){
        if($firstname != "" || $lastname != "" || $email != "" || $subject != "" || $message != "") {
            try{
                $sql = "INSERT INTO contact (FirstName,LastName,Email,Subject,Message)
			    VALUES ('$firstname','$lastname','$email','$subject','$message')";
            
                if ($conn->query($sql)) {
                    $errormessage = $errormessage . "<p class='success'>Form Submitted";
                    // if the data is sent to the database then it will clear the form so the user doesn't accidentally enter data twice
                    $firstname = $lastname = $email = $subject = $message = "";
                    $Error = false;
                } else {
                    $errormessage = $errormessage . "<p class='form-error'>Error: " . $sql . "<br>" . $conn->errorInfo()."</p>";
                }
                $conn = null;
            } catch(PDOException $e){
                $errormessage = $errormessage . "<p class='form-error'>$e</p>";
            }
			
		}
    }

    function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
?>